import React from 'react'
import ButtonsList from './ButtonsList'
import VideosContainer from './VideosContainer'
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import KeyboardArrowLeftIcon from '@mui/icons-material/KeyboardArrowLeft';

const MainContainer = () => {
  return (
    <div>
      <div className='flex items-center'>
        <div className='rounded-full h-7 w-7 ml-2 bg-black text-white'><KeyboardArrowLeftIcon /></div>
        <div><ButtonsList /></div>
        <div className='rounded-full h-7  w-7 bg-black text-white'><KeyboardArrowRightIcon /></div>
      </div>
      <div className='min-h-[54rem] overflow-auto'>
        <VideosContainer />
      </div>
    </div>
  )
}

export default MainContainer

// ButtonList
// VideosContainer