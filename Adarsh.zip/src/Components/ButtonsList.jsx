import React from 'react'
import Buttons from './Buttons'

const ButtonsList = () => {

  const buttonslist = ["All", "Gaming", "Videos", "Cricket", "Songs", "Gym", "Soccer", "Badminton", "All", "Gaming", "Videos", "Cricket", "Songs", "Gym", "Soccer", "Badminton", "All", "Gaming", "Videos", "Cricket", "Songs", "Gym", "Soccer", "Badminton"]

  return (
    <>
      <div className='flex gap-10 p-5 w-[103rem] overflow-hidden'>
        {buttonslist.map((b) => {
          return (
            <Buttons name={b} />
          )
        })}
      </div>
    </>
  )
}

export default ButtonsList