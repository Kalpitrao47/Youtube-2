const GOOGLE_API_KEY = "AIzaSyAWI8km_zGRWeEkU2xV-a27CfKf5PCUjOI"
export const YOUTUBE_VIDEOS_API = "https://youtube.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics&chart=mostPopular&regionCode=&&maxResults=50&key="+GOOGLE_API_KEY;

export const YOUTUBE_COMMENTS_API = "https://youtube.googleapis.com/youtube/v3/comments?part=snippet&parentId=UgzDE2tasfmrYLyNkGt4AaABAg&key="+GOOGLE_API_KEY; 

// export const YOUTUBE_COMMENTS_API_2 = "https://www.googleapis.com/youtube/v3/commentThreads?textFormat=plainText&part=snippet,replies&maxResults=100&key="+GOOGLE_API_KEY;
export const YOUTUBE_COMMENTS_API_2 = (videoId) => 
    `https://www.googleapis.com/youtube/v3/commentThreads?textFormat=plainText&part=snippet,replies&maxResults=100&videoId=${videoId}&key=${GOOGLE_API_KEY}`;
  

export const Video_Details_Api = (videoId) => `https://youtube.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics&id=${videoId}&key=${GOOGLE_API_KEY}`;   